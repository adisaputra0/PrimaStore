class Score{
    constructor(txtScore){
        this.txtScore = txtScore;
        this.score = 0;
        this.intervalScore = null;
    }
    start(){
        this.intervalScore = setInterval(() => {
            this.txtScore.textContent = this.score;
            this.score++;
        }, 100);
    }
    pause(){
        clearInterval(this.intervalScore);
    }
}