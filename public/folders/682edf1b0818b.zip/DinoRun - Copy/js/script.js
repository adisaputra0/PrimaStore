const gameBoard = document.querySelector(".gameBoard");
const txtUsername = document.querySelector("#txtUsername");
const levels = document.querySelector("#levels");
const btnPlay = document.querySelector("#btnPlay");
const cInstruction = document.querySelector(".instruction");
const cLeaderboard = document.querySelector(".leaderboard");
const cMenu = document.querySelector(".cMenu");
const menu = document.querySelector(".menu");
const countDown = document.querySelector(".countDown");
const countDownTime = document.querySelector(".countDown>h1");
const header = document.querySelector(".header");
const character = document.querySelector("#character");
const obstacle = document.querySelector("#obstacle");
const sName = document.querySelector("#sName");
const sScore = document.querySelector("#sScore");
const sLevel = document.querySelector("#sLevel");
const sPause = document.querySelector(".pause");
function check(){
    if(txtUsername.value != ""){
        btnPlay.disabled = false
    }else{
        btnPlay.disabled = true
    }
}
function showInstruction(){
    cInstruction.style.display = "flex";
}
function closeInstruction(){
    cInstruction.style.display = "none";
}

function showLeaderboard(){
    cLeaderboard.style.display = "flex";
}
function closeLeaderboard(){
    cLeaderboard.style.display = "none";
}
function playGame(){
    sName.textContent = txtUsername.value;
    sLevel.textContent = levels.value;
    sScore.textContent = 0;
    menu.style.display = "none";
    countDown.style.display = "flex";
    let countTime = 3;
    const intervalCountDown = setInterval(() => {
        countTime-=1;
        countDownTime.textContent = countTime;
        if(countTime <= 0){
            clearInterval(intervalCountDown);
            cMenu.style.display = "none";
            start();
        }
    }, 1000);
}

const characterClass = new Character(character);
const scoreClass = new Score(sScore);
const gameBoardClass = new GameBoard(gameBoard);
const obstacleClass = new Obstacle(obstacle);

let conditionStart = false;

document.addEventListener("keydown", (e) => {
    if(e.key == "Escape" && conditionStart){
        pause();
    }else if(e.key == "Escape"){
        start();
    }

    if(e.keyCode == 32 && conditionStart){
        characterClass.jump();
    }
});

sName.addEventListener("click", () => {
    if(conditionStart){
        pause();
    }
});
sPause.addEventListener("click", () => {
    start();
});

function start(){
    header.style.display = "grid"
    character.style.display = "inline"
    obstacle.style.display = "inline"
    sPause.style.display = "none"
    conditionStart = true;
    characterClass.animate();
    scoreClass.start();
    gameBoardClass.animate();
    obstacleClass.animate();
}
function pause(){
    characterClass.pause();
    scoreClass.pause();
    sPause.style.display = "flex";
    conditionStart = false;
    gameBoardClass.pause();
    obstacleClass.pause();
}