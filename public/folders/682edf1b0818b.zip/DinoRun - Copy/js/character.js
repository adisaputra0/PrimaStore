class Character{
    constructor(character){
        this.character = character;
        this.characterAnim = 1;
        this.intervalCharacter = null;
        this.startPosition = 40;
        this.positionY = 40;
        this.speedJump = 1;
        this.maxJump = this.positionY*3;
        this.intervalJump = null;
        this.intervalGravity = null;
        this.conditionJump = false;
    }
    animate(){
        this.intervalCharacter = setInterval(() => {
            if(this.characterAnim > 8){
                this.characterAnim = 1;
            }
            this.character.src = `../asset/run${this.characterAnim}.png`;
            this.characterAnim++;
        }, 70);
    }
    pause(){
        clearInterval(this.intervalCharacter);
    }
    jump(){
        if(!this.conditionJump){
            this.conditionJump = true;
            clearInterval(this.intervalCharacter);
            this.intervalJump = setInterval(() => {
                if(this.positionY > this.maxJump){
                    clearInterval(this.intervalJump);
                    this.gravity();
                }
                this.positionY += this.speedJump;
                this.character.style.bottom = this.positionY + "px";
            }, 1);  
        }     
    }
    gravity(){
        this.intervalGravity = setInterval(() => {
            if(this.positionY < this.startPosition){
                clearInterval(this.intervalGravity);
                this.conditionJump = false;
                this.animate();
            }
            this.positionY -= this.speedJump;
            this.character.style.bottom = this.positionY + "px";
        }, 1);        
    }
}