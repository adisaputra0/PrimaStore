class GameBoard{
    constructor(gameBoard){
        this.gameBoard = gameBoard;
        this.positionX = 0;
        this.speedX = 1;
        this.intervalGame = null;
    }
    animate(){
        this.intervalGame = setInterval(() => {
            this.positionX -= this.speedX;
            this.gameBoard.style.backgroundPositionX = this.positionX + "px";
        }, 10);
    }
    pause(){
        clearInterval(this.intervalGame);
    }
}