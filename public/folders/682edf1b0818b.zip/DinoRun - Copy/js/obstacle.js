class Obstacle{
    constructor(obstacle){
        this.obstacle = obstacle;
        this.positionX = -100;
        this.startPositionX = -100;
        this.speedX = 2;
        this.maxX = 700;
        this.intervalObstacle = null;
    }
    animate(){
        this.intervalObstacle = setInterval(() => {
            if(this.positionX > this.maxX){
                this.positionX = this.startPositionX;
            }
            this.positionX += this.speedX;
            this.obstacle.style.right = this.positionX + "px";
        }, 1);
    }
    pause(){
        clearInterval(this.intervalObstacle);
    }
}